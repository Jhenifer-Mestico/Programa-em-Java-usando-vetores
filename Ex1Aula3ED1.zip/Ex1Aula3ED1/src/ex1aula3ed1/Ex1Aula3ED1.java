package ex1aula3ed1;

import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Random;

public class Ex1Aula3ED1 {

    public static void main(String[] args) {
   
        Random rnd = new Random();
        double vetor[] = new double[100];
        int numElem = 7;
        for (int i = 0; i < numElem; i++){
            vetor[i] = rnd.nextDouble()*50;
        }
        System.out.println("Vetor gerado aleatoriamente:");
        visualizarVetor(vetor, numElem);
        inverter(vetor, numElem);
        System.out.println("\nVetor invertido:");
        visualizarVetor(vetor, numElem);
       
       ArrayList <Double> lista = new ArrayList();
       for (int i = 0; i < numElem; i++){
            lista.add(rnd.nextDouble()*50);
        }
        System.out.println("\nArrayList gerado aleatoriamente:");
        visualizarArrayList(lista);
        inverterArrayList(lista);
        System.out.println("\nArrayList invertido:");
        visualizarArrayList(lista);
    }
    public static void inverter(double vet[], int n){
        for (int i = 0; i < n/2; i++){
            double temp = vet[i];
            vet[i] = vet[n-1-i];
            vet[n-1-i] = temp;
       }
    }
    public static void visualizarVetor(double vet[], int n){
        for(int i = 0; i < n; i++){
            System.out.printf("%.2f%s", vet[i], " || " );
        }
    }
    public static void inverterArrayList(ArrayList<Double> vetor){
        int n = vetor.size();
        for(int i = 0; i < vetor.size()/2; i++){
            double temp = vetor.get(i);
            vetor.set(i, vetor.get(n - 1 - i));
            vetor.set(n - 1 - i, temp);
        }  
    }
    public static void visualizarArrayList(ArrayList vetor){
        for(int i = 0; i < vetor.size(); i++){
            System.out.printf("%.2f%s", vetor.get(i), " || ");
        }
    }
}